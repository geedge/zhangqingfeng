import json
import random
import time
import requests

def print_circuit(url):
    '''
    获取链路
    :return:
    '''
    current_url = url + "print_circuit"
    #channel_name = self.url.strip().split(":")[1].split(".")[-1]
    #print("网址:{}".format(current_url))
    try:
        res = requests.get(current_url)
        s= json.loads(res.text)
        return s
        for i in s:
            print("通道{} {}".format(i,str(s[i])))
    except Exception as e:
        print("obtain_config_info function occurs error:{}".format(e))
        return ''
if __name__ == "__main__":
    print(print_circuit("http://172.17.0.5:60001/"))
    pass
