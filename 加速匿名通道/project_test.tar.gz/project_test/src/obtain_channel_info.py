# -*- coding: utf-8 -*-
# @Time: 2021/11/12 17:35
# @Auth: ZhangQingFeng
# @File: test_flask_function.py
# @IDE: PyCharm
# @Email: zhangqingfeng0105@163.com
import json
import random
import time

import requests

class TestFlask:
    def __init__(self, channel_id):
        self.url = channel_id
        pass

    def obtain_config_info(self) -> object:
        '''
        获取通道的配置
        :return:
        '''
        current_url = self.url + "obtain_config_info"
        print("网址:{}".format(current_url))
        try:
            res = requests.get(current_url)
            print(res.text)
        except Exception as e:
            print("obtain_config_info function occurs error:{}".format(e))

    def print_circuit(self):
        '''
        获取链路
        :return:
        '''
        current_url = self.url + "print_circuit"
        channel_name = self.url.strip().split(":")[1].split(".")[-1]
        #print("网址:{}".format(current_url))
        try:
            res = requests.get(current_url)
            s= json.loads(res.text)
            for i in s:
                print("通道{} {}".format(i,str(s[i])))
        except Exception as e:
            print("obtain_config_info function occurs error:{}".format(e))

    def modify_config_file(self,config_params):
        '''
        修改通道的config文件，修改内容为config_params,类型为dict
        :param config_params:
        :return:
        '''
        current_url = self.url + "modify_config_file"
        print("网址:{}".format(current_url))
        param_data = {"data":(None,config_params)}
        try:
            res = requests.post(current_url,data=param_data)
            print(res.text)
        except Exception as e:
            print("obtain_config_info function occurs error:{}".format(e))

    def custom_circuit(self,route_length,node_type,node_str,node_config):
        '''
        创建自定义链路
        :param route_length:
        :param node_type: 两个取值,  "public"   "private"
        :param node_str:  节点字符串，用逗号拼接,"xsadas,sadasf"
        :param node_config: 一个json串，例入：'{”bandwd_standard":"mean","circuit_purpose":0}'
        :return:
        '''
        current_url = self.url + "custom_circuit"
        print("网址:{}".format(current_url))
        param_data = {"route_length":(None,route_length),
                      "node_type":node_type,
                      "node_str":node_str,
                      "node_config":node_config}
        try:
            res = requests.post(current_url,data=param_data)
            print(res.text)
        except Exception as e:
            print("obtain_config_info function occurs error:{}".format(e))


