socks_port_zqf=50002
flask_port_zqf=60002
ssh_port_zqf=40002
local_ip="192.248.189.163"
rm -rf /root/project_test/node_file/channel_info.txt
rm -rf /root/project_test/node_file/channel_socks.txt
times_zqf=2
end_times_zqf=$times_zqf+$1
docker_num=0
for ((times_zqf; times_zqf<end_times_zqf; times_zqf++))
  do
  tor_name="channel_acceleration${times_zqf}"
  channel_flask="${local_ip}:${flask_port_zqf}"
  echo $channel_flask >> /root/project_test/node_file/channel_info.txt

  channel_socks="socks5h://${local_ip}:${socks_port_zqf}"
  echo $channel_socks >> /root/project_test/node_file/channel_socks.txt

  docker run -itd --name $tor_name -h $tor_name -p $ssh_port_zqf:22 -p $socks_port_zqf:$socks_port_zqf -p $flask_port_zqf:$flask_port_zqf channel_acceleration_base:v1 /bin/bash
  
  docker exec -i $tor_name sed -i "1c \SocksPort 0.0.0.0:${socks_port_zqf} IsolateDestAddr" /home/torProject/torrc
  docker exec -i $tor_name sed -i "5c \TOR_MYSELF_PROXY=\"socks5://127.0.0.1:${socks_port_zqf}\"" /home/channel_acceleration/src/config.py
  docker exec -i $tor_name sed -i "6c \TOR_PROXY=\"socks5h://127.0.0.1:${socks_port_zqf}\"" /home/channel_acceleration/src/config.py
  docker exec -i $tor_name sed -i "15c \FLASK_CONTROL_PORT=${flask_port_zqf}" /home/channel_acceleration/src/config.py

  docker exec -i $tor_name sed -i "s/\r//g" /home/torProject/torrc
  docker exec -i $tor_name sed -i "s/\r//g" /home/channel_acceleration/src/config.py

  docker exec -d $tor_name /bin/bash -c 'bash /home/channel_acceleration/src/first_start.sh'
  docker exec -d $tor_name service cron start
  
  ssh_port_zqf=$(($ssh_port_zqf+1))
  flask_port_zqf=$(($flask_port_zqf+1))
  socks_port_zqf=$(($socks_port_zqf+1))
  
  docker_num=$(($docker_num+1))
  done

echo "部署${docker_num}个通道完毕!"

