import config
import visit_target_url
import return_circuit
import concurrent.futures as con_futures

def read_channel(file_path=config.CHANNEL_INFO):
    '''
    读取所有通道的ip
    '''
    channel_list = []
    channel_socks_list = []
    channel_flask_list = []
    fr_flask = open(config.CHANNEL_INFO,"r", encoding='utf-8')
    fr_socks = open(config.CHANNEL_SOCKS, "r", encoding='utf-8')
    for one_channel in fr_flask:
        if one_channel:
            flask_ip_port = one_channel.strip()
            flask_ip, flask_port = flask_ip_port.split(":")
            channel_list.append(int(flask_port))
            channel_flask_list.append("http://{}/".format(flask_ip_port))

    for one_channel in fr_socks:
        if one_channel:
            channel_socks_list.append(one_channel.strip())

    fr_flask.close()
    fr_socks.close()
    return channel_list, channel_socks_list, channel_flask_list

def main_func_helper(channel_name, channel_socks,  channel_flask):
    '''
    main_func函数的辅助函数
    '''
    actual_ip = visit_target_url.probe_actual_ip(channel_socks)
    try:
        circuit_info = list(return_circuit.print_circuit(channel_flask).values())[0]
        return "通道{}: {} - {} ~ {}".format(channel_name,channel_socks, circuit_info, actual_ip)
    except Exception as e:
        return "通道{}: {} 正在初始化, 请重试!".format(channel_name, channel_socks)


def main_func():
    '''
    主函数入口
    '''
    thread_pool = con_futures.ThreadPoolExecutor(max_workers=config.THREAD_NUM)
    channel_list, channel_socks_list, channel_flask_list = read_channel()

    pool_handle = []
    for ind in range(len(channel_socks_list)):
        channel_name = str(channel_list[ind]-60000)
        pool_handle.append(thread_pool.submit(main_func_helper, channel_name, channel_socks_list[ind],channel_flask_list[ind]))
    
    for pool_result in con_futures.as_completed(pool_handle):
        print(pool_result.result())

if __name__ == '__main__':
    main_func()

