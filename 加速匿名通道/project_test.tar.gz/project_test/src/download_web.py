import config
import sys
import requests
import random
import time
import json



user_agent_list = [
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)",
        "Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.5; en-US; rv:1.9.2.15) Gecko/20110303 Firefox/3.6.15",
    ]

def probe_actual_ip(url, tor_socks,fw_html, timeout_control=config.WEB_TIMEOUT):
    '''
    探测可以返回ip地址的网站,返回访问网站的真实IP和访问所需要的时间
    :return:
    '''
    proxies = {"http":tor_socks, "https":tor_socks}
    headers = {}
    headers['User-Agent'] = random.choice(user_agent_list)
    s = requests.session()
    s.headers = headers
    s.keep_alive = False
    try:
        start_time = time.time()
        req = s.get(url, proxies=proxies,timeout=timeout_control,stream=True)
        end_time = time.time()
        html_content = req.content
        fw_html.write(html_content)
        req.close()
        s.close()
        return 1
    except requests.exceptions.ConnectionError as e:
        print("Error1 is:{}".format(e))
        s.close()
        return 0
    except requests.exceptions.RequestException as e2:
        print("Error2 is:{}".format(e2))
        s.close()
        return 0
    except Exception as e3:
        print("Error3 is {}".format(e3))
        s.close()
        return 0

def download_web_html():
    '''
    下载html
    '''
    try: 
        url = sys.argv[1]
        socks_ip = sys.argv[2]
        socks_transfer = "socks5h://{}".format(socks_ip)
        print("正在使用{} 访问 {}".format(socks_transfer, url))
       
        domain_name = url.strip().split("//")[-1]
        if domain_name[-1] == "/":
            domain_name = domain_name[:-1]
        domain_name = domain_name.replace("/",".")
        html_path = config.HTML_PATH + domain_name + ".html"
        fw_html = open(html_path, "wb")
        res_status = probe_actual_ip(url, socks_transfer, fw_html, 59)
        fw_html.close()
        if res_status:
            print("{}访问成功!".format(domain_name))
        else:
            print("{}访问失败!".format(domain_name))

    except Exception as e:
        print("请按照 python3 download_web.py [url] [socks_ip:socks_port]的方式使用!")

if __name__ == "__main__":
    download_web_html()
