import config
import requests
import random
import time
import json

user_agent_list = [
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)",
        "Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.5; en-US; rv:1.9.2.15) Gecko/20110303 Firefox/3.6.15",
    ]

def probe_actual_ip(tor_socks,timeout_control=config.WEB_TIMEOUT):
    '''
    探测可以返回ip地址的网站,返回访问网站的真实IP和访问所需要的时间
    :return:
    '''
    proxies = {"http":tor_socks, "https":tor_socks}
    headers = {}
    headers['User-Agent'] = random.choice(user_agent_list)
    s = requests.session()
    s.headers = headers
    s.keep_alive = False
    try:
        start_time = time.time()
        req = s.get(config.TARGET_URL, proxies=proxies,timeout=timeout_control)#.json()   #http://ip-api.com/json  http://eeblrw5eh2is36az.onion
        end_time = time.time()
        req_text = req.text
        actual_ip = json.loads(req_text)["query"]       #query
        req.close()
        s.close()
        return actual_ip
    except requests.exceptions.ConnectionError as e:
        print("Error1 is:{}".format(e))
        s.close()
        return None
    except requests.exceptions.RequestException as e2:
        print("Error2 is:{}".format(e2))
        s.close()
        return None
    except Exception as e3:
        print("Error3 is {}".format(e3))
        s.close()
        return None

