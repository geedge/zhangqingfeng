import config
import logging
import os
import return_circuit

def init_log(path):
    if os.path.exists(path):
        mode = 'a'
    else:
        mode = 'w'
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(message)s',
        filename=path,
        filemode=mode)
    return logging

def obatin_circuit_info_path():
    '''
    获取circuit_log的路径
    '''
    return config.CHANNEL_CIRC_LOG

logs = init_log(obatin_circuit_info_path())

def read_channel(file_path=config.CHANNEL_INFO):
    '''
    读取所有通道的ip
    '''
    channel_list = []
    channel_socks_list = []
    channel_flask_list = []
    fr_flask = open(config.CHANNEL_INFO,"r", encoding='utf-8')
    fr_socks = open(config.CHANNEL_SOCKS, "r", encoding='utf-8')
    for one_channel in fr_flask:
        if one_channel:
            flask_ip_port = one_channel.strip()
            flask_ip, flask_port = flask_ip_port.split(":")
            channel_list.append(int(flask_port))
            channel_flask_list.append("http://{}/".format(flask_ip_port))

    for one_channel in fr_socks:
        if one_channel:
            channel_socks_list.append(one_channel.strip())

    fr_flask.close()
    fr_socks.close()
    return channel_list, channel_socks_list, channel_flask_list

def get_circ_info():
    '''
    获取所有链路信息并写入文件
    '''
    channel_list, channel_socks_list, channel_flask_list = read_channel()
    #with open(config.CHANNEL_CIRC_LOG, "a+", encoding='utf-8') as circ_log_fw:
    for ind in range(len(channel_flask_list)):
        channel_name = str(channel_list[ind]-60000)
        try:
            circuit_info = list(return_circuit.print_circuit(channel_flask_list[ind]).values())[0]
            logs.warning("通道{}: {} - {}\n".format(channel_name,channel_socks_list[ind], circuit_info))
        except Exception as e:
            logs.warning("通道{}: {} - None\n".format(channel_name,channel_socks_list[ind]))

if __name__ == "__main__":
    get_circ_info()
