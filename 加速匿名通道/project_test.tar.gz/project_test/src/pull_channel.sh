sshpass -p 'qingfeng0105@' scp root@192.248.189.163:/root/project_test/node_file/channel_info.txt /root/project_test/node_file/
sshpass -p 'qingfeng0105@' scp root@192.248.189.163:/root/project_test/node_file/channel_socks.txt /root/project_test/node_file/
