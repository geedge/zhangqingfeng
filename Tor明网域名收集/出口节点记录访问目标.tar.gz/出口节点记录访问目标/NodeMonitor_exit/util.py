# -*- coding:utf-8 -*-
import subprocess
import logging
import logging.handlers
import shortuuid
import os
import psutil
import socket
from urllib.request import urlopen
from json import load

def query(url):
    import pycurl
    import io   
    import certifi
    output = io.BytesIO()

    query = pycurl.Curl()
    query.setopt(pycurl.CAINFO, certifi.where())
    query.setopt(pycurl.URL, url)
    query.setopt(pycurl.WRITEFUNCTION, output.write)

    try:
        query.perform()
        return output.getvalue()
    except pycurl.error as exc:
        return "Unable to reach %s (%s)" % (url, exc)


def obtain_host_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    host_ip = s.getsockname()[0]
    host_ip = host_ip if host_ip else get_ip_addr_net()
    return host_ip

def obtain_host_ip_new():

    #my_ip = urlopen('http://ip.42.pl/raw').read()
    my_ip = load(urlopen('http://httpbin.org/ip'))['origin']
    return my_ip

def get_ip_addr_net():
    ip_addr = None
    import re
    try:
        ip_addr = query("https://ifconfig.me/ip")
    except:
        pass
    return ip_addr





def get_ip_addr(home_folder):
    import os
    ip_address_file = os.path.join(home_folder,"ip_addr")
    if os.path.exists(ip_address_file):
        file = open(ip_address_file,"r")
        content = file.read()
        ip_addr = content.strip()
        file.close()
        return ip_addr
    ip_net = get_ip_addr_net()

    if ip_net != None:
        file = open(ip_address_file,"w")
        file.write(ip_net.strip())
        file.close()
        return ip_net.strip()

    ip_local = get_ip_addr_local()
    return ip_local


def init_logger(logger_folder, logger_name, logger_level):
    
    logger = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s\t%(levelname)s\tline-%(lineno)d  %(funcName)s  %(message)s')

    file_handler = logging.handlers.RotatingFileHandler(filename="%s/%s.log"%(logger_folder, logger_name),maxBytes=10*1024*1024,backupCount=10)
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    
    logger.addHandler(stream_handler)
    logger.addHandler(file_handler)
    logger.setLevel(logger_level)
    logger.debug("logger %s init done"%logger_name)
    return logger

def run_system_command(cmd_zqf):
    '''
    execute the system command <cmd_zqf>, and return the result.
    :param cmd_zqf: the system command, for example: <ps -aux>
    :return: the result list of executing the command <cmd_zqf>
    '''
    command_result_list = []
    p = subprocess.Popen(cmd_zqf, shell=True, stdout=subprocess.PIPE)
    out, err = p.communicate()
    for line in out.splitlines():
        command_result_list.append(str(line, "utf-8"))
    return command_result_list

def check_exists_process(process_name):
    '''
    monitor the process of ModeMonitor.py
    :return:
    '''
    try:
        all_processes = list(psutil.process_iter())
        cnt = 0
        for proc in all_processes:
            cmdline = proc.cmdline()
            if len(cmdline) < 2:
                continue
            if process_name in cmdline[1] or cmdline[1] == process_name:
                cnt += 1
                if cnt == 2:
                    return 1
        return 0
    except Exception as e:
        print("e",str(e))
        return 2

def check_exists_pid(process_name_list,except_name_list = None):
    
    if type(process_name_list) == str:
        process_name_list = [process_name_list]
    if except_name_list == None:
        except_name_list = []
    if len(set(process_name_list) & set(except_name_list)) != 0:
        return []

    grep_str = "ps -ef |grep -v grep |"
    for process in process_name_list:
        grep_str += "grep %s|" % process
    for process in except_name_list:
        grep_str += "grep -v %s|" % process        
    cmd = grep_str + "awk {'print $2'}|xargs echo"
    p = os.popen(cmd)
    string = p.read()
    pid_list = [int(p_str) for p_str in string.split()]
    return pid_list




def get_uuid():
    uuid = shortuuid.uuid()
    return uuid



if __name__ == "__main__":
    print(check_exists_process('MainMonitor'))
