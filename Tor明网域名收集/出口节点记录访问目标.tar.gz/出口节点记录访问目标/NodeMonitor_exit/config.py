# -*- coding:utf-8 -*-
import socket
import os
import logging
from util import *


HOME_FOLDER = os.path.abspath(os.path.dirname(__file__))
# HOME_FOLDER = "/mnt/c/Users/ChenMQ/Desktop/project/seq_collector/reader"
CONFIG_FOLDER = os.path.join(HOME_FOLDER,"config")


###########################################################################################
## LOG
###########################################################################################

LOG_FOLDER = os.path.join(HOME_FOLDER,"log")
LOG_LEVEL =  logging.INFO


## MONITOR
###########################################################################################
MONITOR_IP = obtain_host_ip_new()
print("my ip is {}".format(MONITOR_IP))
CELL_SEQ_FILE = "/root/logfile/notice.log"
MAX_FILE_LEN = 1024*1024*1024*2
